export interface AlbumUploadInfo {
  name: string
  details: string
  location:string
}
