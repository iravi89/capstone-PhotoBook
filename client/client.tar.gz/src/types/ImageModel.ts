export interface ImageModel {
  title: string
  imageId: string
  imageUrl: string
  albumId: string
  timestamp: string

  isPin?: boolean
}
