export interface ImageUploadInfo {
  albumId: string,
  title: string
}
