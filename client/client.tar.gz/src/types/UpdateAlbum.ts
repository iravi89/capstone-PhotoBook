export interface UpdateAlbum {
    id: string
    name: string
    description: string
    location:string
  }