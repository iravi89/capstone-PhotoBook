export interface AlbumModel {
  id: string
  name: string
  description: string
  location:string
  timestamp:string
}
