export interface UpdateAlbumInfo {
    name: string
    details: string
    location:string
  }