const apiId = 'vlzyigwiwc'//'iwkce2tvti'
export const apiEndpoint = `https://${apiId}.execute-api.us-east-1.amazonaws.com/dev`



export const authConfig = {
  // domain: 'dev-4j7w7l3d.auth0.com',
  // clientId: '1xNGGmq1Yy7H9OIvPHMuvLjD763el3kQ',
  // callbackUrl: 'http://localhost:3000/callback'

  domain: 'dev-2tg8uth4.us.auth0.com',
  clientId: 'u4LRFFjbD0UI3DthiriO4gW9fj6cmyME',
  callbackUrl: 'http://localhost:3000/callback'
}
